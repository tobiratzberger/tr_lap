<?php
    /*
    *   Author: Tobias Ratzberger
    *   Subject: Prüfarbeit Software (PHP / MySQL)
    *   File: blank.php
    */

    echo "Ich bin eine leere Datei";
?>