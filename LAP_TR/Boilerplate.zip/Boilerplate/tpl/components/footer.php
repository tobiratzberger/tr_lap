<?php
    /*
    *   Author: Tobias Ratzberger
    *   Subject: Prüfarbeit Software (PHP / MySQL)
    *   File: footer.php
    */
?>

<footer class="container">
    <p>© <?php echo date("Y") . " " . $config->author; ?></p>
</footer>